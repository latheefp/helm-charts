{{/*
Expand the name of the chart.
*/}}
{{- define "secureshift.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
*/}}
{{- define "secureshift.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Chart label
*/}}
{{- define "secureshift.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "secureshift.labels" -}}
helm.sh/chart: {{ include "secureshift.chart" . }}
{{ include "secureshift.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "secureshift.selectorLabels" -}}
app.kubernetes.io/name: {{ include "secureshift.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
DB selector labels
*/}}
{{- define "secureshift.dbSelectorLabels" -}}
app.kubernetes.io/name: {{ include "secureshift.name" . }}-db
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Name of the DB secret — either an existing secret or the one this chart creates.
*/}}
{{- define "secureshift.dbSecretName" -}}
{{- if .Values.db.existingSecret }}
{{- .Values.db.existingSecret }}
{{- else }}
{{- include "secureshift.fullname" . }}-db-secret
{{- end }}
{{- end }}

{{/*
Fully qualified DB service hostname
*/}}
{{- define "secureshift.dbHost" -}}
{{- printf "%s-db" (include "secureshift.fullname" .) }}
{{- end }}
