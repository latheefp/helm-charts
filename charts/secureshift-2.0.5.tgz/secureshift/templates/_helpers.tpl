{{- define "secureshift.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "secureshift.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{- define "secureshift.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "secureshift.labels" -}}
helm.sh/chart: {{ include "secureshift.chart" . }}
{{ include "secureshift.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{- define "secureshift.selectorLabels" -}}
app.kubernetes.io/name: {{ include "secureshift.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{- define "secureshift.dbSelectorLabels" -}}
app.kubernetes.io/name: {{ include "secureshift.name" . }}-db
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/* Name of the DB secret — either an existing secret or the chart-managed one. */}}
{{- define "secureshift.dbSecretName" -}}
{{- if .Values.db.existingSecret }}
{{- .Values.db.existingSecret }}
{{- else }}
{{- include "secureshift.fullname" . }}-db-secret
{{- end }}
{{- end }}

{{/* DB hostname — in-cluster headless Service when db.enabled=true, else db.host. */}}
{{- define "secureshift.dbHost" -}}
{{- if .Values.db.enabled }}
{{- printf "%s-db" (include "secureshift.fullname" .) }}
{{- else }}
{{- required "db.host must be set when db.enabled is false" .Values.db.host }}
{{- end }}
{{- end }}
